
## Linus Torvalds

## Donald Ervin Knuth
* TeX
* The Art of Computer Programming

## Leslie Lamport
* LaTeX as macros of TeX

## Claudia Eckert

## Bruce Schneier

## Richard Stallman
* launched GNU project

## Edsger Dijkstra

## Guido van Rossum
* Python

## Edgar F. Codd
* relational model for database management

## Grace Hopper
* the concept of programming languages

## John von Neumann
* EVA

## Terry Davis
* Temple OS